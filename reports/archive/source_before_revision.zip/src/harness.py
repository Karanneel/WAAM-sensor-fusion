"""
closed-loop experiment harness. ties the sim, sensors, estimator and
controller together into one function so the planted-error sweep can call it
many times.

per layer:
  deposit physically, update truth state
  observe (noisy obs from sensors)
  estimator consumes obs, returns state estimate
  controller consumes estimate, decides ts for the next layer

the controller adjusts travel speed based on estimated height error.
too tall -> faster travel -> thinner bead -> less growth per layer.
Z advances by estimated growth to maintain standoff.

final outcome: wall-height error against a reference target. that is the
Q8 scoring metric
"""

import math
import numpy as np

from process import deposit, S_NOM
from simulator import (T_AMB, R_Z_CMD, START_Z, WFS_CMD, TS_CMD,
                       thermal_update)
from sensors import SensorState, observe


NOMINAL_STANDOFF = S_NOM

# nominal per-layer wall growth at calibrated params
NOMINAL_GROWTH = 1.8                 # mm per layer at dwell=60 reference

# ts clamps: don't let travel speed go below half or above double nominal
TS_MIN = TS_CMD * 0.5               # 5 mm/s
TS_MAX = TS_CMD * 2.0               # 20 mm/s

# ts controller gain: mm/s of ts adjustment per mm of height error.
# positive because too-tall -> increase ts -> thinner bead
TS_GAIN_DEFAULT = 2.0

# r_z clamp for the Z advancement (standoff maintenance, not a control lever)
R_Z_MIN, R_Z_MAX = 0.5, 3.5


def run_closed_loop(n_layers, dwell, seed, estimator_builder,
                    controller_gain=1.0, target_wall_height=None,
                    wfs=WFS_CMD, ts=TS_CMD, start_z=START_Z,
                    ctwd_quad=0.005, sealed=False, spatter_p=0.02):
    """run one closed-loop build.

    controller_gain scales the ts feedback strength.
    sealed=True enables the pre-registered sealed-generator check.
    returns (rows, estimates, controls, metrics, obs_list)"""
    shape = 3.0 / 4.0 if sealed else None
    beta = 0.85 if sealed else 1.0
    ctwd_bias0 = 0.5 if sealed else 0.0

    rng = np.random.default_rng(seed)
    sens_rng = np.random.default_rng(seed + 1000)
    sens_state = SensorState(sens_rng, ctwd_quad=ctwd_quad,
                             ctwd_bias0=ctwd_bias0)
    est = estimator_builder()

    H = 0.0
    Z = start_z
    T = T_AMB
    prev_H = 0.0

    rows, estimates, controls, obs_list = [], [], [], []

    # per-layer target height for the controller
    target_per_layer = NOMINAL_GROWTH

    # first layer: nominal ts and r_z
    ts_next = ts
    r_z_next = NOMINAL_GROWTH

    for k in range(1, n_layers + 1):
        standoff = Z - H
        area, width, height, regime = deposit(wfs, ts_next, standoff, T,
                                              shape=shape)
        spatter = rng.random() < spatter_p
        H_out = H + height
        T_out = thermal_update(T, H_out, dwell, ts_next, beta=beta)

        row = {"layer": k, "H_in": H, "Z": Z, "standoff": standoff,
               "T_in": T, "T_out": T_out, "area": area, "width": width,
               "height": height, "regime": regime, "spatter": spatter,
               "H_out": H_out, "ts": ts_next}
        rows.append(row)

        obs = observe(row, prev_H, sens_state)
        obs_list.append(obs)
        ctrl = {"wfs": wfs, "ts": ts_next, "r_z": r_z_next, "dwell": dwell}
        est_out = est.update(obs, ctrl)
        estimates.append(est_out)

        # controller: adjust travel speed based on height error
        # target cumulative H at this layer
        target_H = k * target_per_layer
        h_err = est_out["H"] - target_H
        # positive h_err means wall is too tall, so increase ts
        ts_adj = controller_gain * TS_GAIN_DEFAULT * h_err
        ts_next = ts + ts_adj
        ts_next = max(TS_MIN, min(TS_MAX, ts_next))

        # Z advancement: track estimated growth to maintain standoff.
        # this is geometry, not a control lever. estimate how much the
        # wall grew this layer and advance Z by that amount
        est_growth = est_out["H"] - (estimates[-2]["H"] if k > 1 else 0.0)
        r_z_next = max(R_Z_MIN, min(R_Z_MAX, est_growth))

        controls.append({"r_z": r_z_next, "ts": ts_next})

        H = H_out
        Z = Z + r_z_next
        T = T_out
        prev_H = H_out

    if target_wall_height is None:
        target_wall_height = n_layers * target_per_layer
    metrics = {
        "final_H":        H,
        "target_H":       target_wall_height,
        "wall_err":       abs(H - target_wall_height),
        "last_standoff":  rows[-1]["standoff"],
        "mean_ts":        float(np.mean([r["ts"] for r in rows])),
    }
    return rows, estimates, controls, metrics, obs_list
